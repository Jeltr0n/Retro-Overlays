This filter was created by @eggs

You can simply open the .filt file with a text editor and change the number to change how many pixels you want to offset the image by.

It is probably a good idea to also edit the offset_upXXpx.filt file name to reflect the change. 

Do not edit the name of the .so file