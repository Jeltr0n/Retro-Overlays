These filters are designed to go with my GB & GBA overlays. They offset the screens by moving them up- this is to allow more art on the bottom and have full-sized GB logos. They were made by akouzoukos- creator of Apotris!

DMG_GreenGrid should be used with the palette: /essentials/GB-DMG

GBP_GrayGrid should be used with the palette: /essentials/GB-Pocket